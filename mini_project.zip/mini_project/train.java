import java.io.*;
class main
{
	public static void main(String z[])throws Exception
	{
		first f1=new first();
		f1.qq();
	}
}
class train
{
		String no;
		String name;
		String sno;
		String from;
		String to;
		void insert()throws Exception
		{
			FileWriter f=new FileWriter("train.txt",true);
			BufferedWriter b=new BufferedWriter(f);
			InputStreamReader i=new InputStreamReader(System.in);
			BufferedReader bi=new BufferedReader(i);
			System.out.println("enter train no: ");
			no=bi.readLine();
			b.write("train no: "+no);
			b.newLine();
			System.out.println("enter train name: ");
			name=bi.readLine();
			b.write("train name: "+name);
			b.newLine();
			System.out.println("from where: ");
			from=bi.readLine();
			b.write("from: "+from);
			b.newLine();
			System.out.println("to:");
			to=bi.readLine();
			b.write("to: "+to);
			b.newLine();
			b.close();
		}
		void exit()throws Exception
		{
			System.exit(0);
		}
		void search()throws Exception
		{
			FileReader fr=new FileReader("train.txt");
			BufferedReader br=new BufferedReader(fr);
			System.out.println("enter train no:");
			InputStreamReader isr=new InputStreamReader(System.in);
			BufferedReader bsr=new BufferedReader(isr);
			sno=bsr.readLine();
			String cm;
			while((cm=br.readLine())!=null)
			{
					String a[]=cm.split(" ");
				for(int i=0;i<a.length;i++)
				{
					if(sno.equals(a[i]))
					{
						System.out.println(br.readLine());
						System.out.println(br.readLine());
						System.out.println(br.readLine());
					}
				}
			}
		}
}
class first
{
	void qq()throws Exception  
	{
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader bi=new BufferedReader(i);
		train t1=new train();
		String ask;
		do
		{
			System.out.println("1 insert");
			System.out.println("2 search");
			System.out.println("3 exit");
			System.out.println("enter your choice");
			String s=bi.readLine();
			switch (s)
				{
					case "1":	t1.insert();
								break;
					case "3":   t1.exit();
								break;
					case "2":	t1.search();
								break;
				}
			System.out.println("do you want to continue: ");
			ask=bi.readLine();
		}while(ask.equals("y"));
	}
}

