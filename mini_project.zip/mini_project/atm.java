class abc
{
	int amount=10000;
	synchronized void s(int limit)throws Exception
	{
		//Thread.sleep(2000);						//
		amount=amount-limit;
		if(amount<3000)
		{
			amount+=limit;
			System.out.println("not");
		}
		else
			System.out.println("balance is="+amount);
	}
}
class xyz implements Runnable
{
	int limit;
	abc a;
	Thread t=new Thread(this);
	xyz(abc a1,int l)
	{
		limit=l;
		a=a1;
		t.start();
	}
	public void run()
	{
		try{
		a.s(limit);}
		catch(Exception e){}
	}
}
class main
{
	public static void main(String z[])throws Exception
	{
		abc a1=new abc();
		xyz x1=new xyz(a1,4000);
	//	x1.t.join();
		xyz x2=new xyz(a1,1000);
	//	x2.t.join();
		xyz x3=new xyz(a1,2000);
	//	x3.t.join();
		xyz x4=new xyz(a1,3000);
	//	x4.t.join();
	}
}