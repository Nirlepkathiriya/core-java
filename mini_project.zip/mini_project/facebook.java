import java.io.*;
//class yes extends Exception{}
class no extends Exception{}
class facebook
{
	String user,pass;
	int flag=0;
	void s()throws Exception
		{
			FileWriter f=new FileWriter("fb.txt");
			BufferedWriter b=new BufferedWriter(f);
			b.write("username     password");
			b.close();
		}
	void s1()throws Exception
		{
				InputStreamReader i=new InputStreamReader(System.in);
				BufferedReader bi=new BufferedReader(i);
				System.out.println("enter usernae:");
				user=bi.readLine();
				System.out.println("enter password:");
				pass=bi.readLine();
		}
	void s2()throws Exception
		{
				FileReader f1=new FileReader("fb.txt");
				BufferedReader b1=new BufferedReader(f1);
				String s3;
				while((s3=b1.readLine())!=null)
				{
					String a[]=s3.split("  ");
					if(a[0].equals(user) && a[1].equals(pass))
					{flag=1;break;}
			}
					try
					{
						if(flag==1)
						{
							System.out.println("welcome");
						//	yes y=new yes();
						//	throw y;
						}
						else
						{
							System.out.println("no welcome");
							no n=new no();
							throw n;
						}
					}
					catch(no n){System.exit(0);}
					
						System.out.println("hilil");
						System.out.println("byyyewfwe");
	
	//				catch(no n){}
					
				}	
			
}
class main
{
	public static void main(String z[])throws Exception
	{
		facebook fb=new facebook();
		//fb.s();
		fb.s1();
		fb.s2();
	}
}